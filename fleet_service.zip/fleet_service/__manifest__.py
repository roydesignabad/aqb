# -*- coding: utf-8 -*-
{
    'name': "fleet_service",

    'summary': "Short (1 phrase/line) summary of the module's purpose",

    'description': """
Fleet Service Manager
    """,

    'author': "My Company",
    'website': "https://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/15.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','fleet','mail'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/fleet_service_views.xml',
    ],
    'license':'LGPL-3',
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
    'addplication': True
}

